#include <stdio.h>
#include <stdlib.h>
#include <mpi.h>

int *formaMatriz(int n, int m) {
    int *mat;
    mat = (int *)calloc(n * m, sizeof(int));
    for (int i = 0; i < n; i++) {
        for (int j = 0; j < m; j++) {
            mat[i * m + j] = i;
        }
    }
    return mat;
}

void imprimeMat(int *M, int n, int m) {
    for (int i = 0; i < n; i++) {
        for (int j = 0; j < m; j++) {
            printf("%d ", M[i * m + j]);
        }
        printf("\n");
    }
}

void sumaMatrices(int *M1, int *M2, int *resultado, int n, int m) {
    for (int i = 0; i < n; i++) {
        for (int j = 0; j < m; j++) {
            resultado[i * m + j] = M1[i * m + j] + M2[i * m + j];
        }
    }
}

int main(int argc, char *argv[]) {
    int np, id;
    MPI_Status estado;
    int *M1, *M2, *resultado, renEnviar, nren, offset = 0, sobran;
    int n = 10, m = 10;

    MPI_Init(&argc, &argv);
    MPI_Comm_rank(MPI_COMM_WORLD, &id);
    MPI_Comm_size(MPI_COMM_WORLD, &np);

    if (id == 0) {
        M1 = formaMatriz(n, m);
        M2 = formaMatriz(n, m);
        resultado = (int *)calloc(n * m, sizeof(int));

        printf("Matriz 1:\n");
        imprimeMat(M1, n, m);
        printf("\nMatriz 2:\n");
        imprimeMat(M2, n, m);

        nren = n / (np - 1);
        sobran = n % (np - 1);

        for (int i = 1; i < np; i++) {
            renEnviar = (i <= sobran) ? nren + 1 : nren;
            MPI_Send(&renEnviar, 1, MPI_INT, i, 0, MPI_COMM_WORLD);
            MPI_Send(&M1[offset * m], renEnviar * m, MPI_INT, i, 0, MPI_COMM_WORLD);
            MPI_Send(&M2[offset * m], renEnviar * m, MPI_INT, i, 0, MPI_COMM_WORLD);
            offset += renEnviar;
        }

        offset = 0;
        for (int i = 1; i < np; i++) {
            renEnviar = (i <= sobran) ? nren + 1 : nren;
            MPI_Recv(&resultado[offset * m], renEnviar * m, MPI_INT, i, 0, MPI_COMM_WORLD, &estado);
            offset += renEnviar;
        }

        printf("\nMatriz resultado:\n");
        imprimeMat(resultado, n, m);

        free(M1);
        free(M2);
        free(resultado);
    } else {
        MPI_Recv(&renEnviar, 1, MPI_INT, 0, 0, MPI_COMM_WORLD, &estado);
        M1 = (int *)malloc(renEnviar * m * sizeof(int));
        M2 = (int *)malloc(renEnviar * m * sizeof(int));
        resultado = (int *)malloc(renEnviar * m * sizeof(int));

        MPI_Recv(M1, renEnviar * m, MPI_INT, 0, 0, MPI_COMM_WORLD, &estado);
        MPI_Recv(M2, renEnviar * m, MPI_INT, 0, 0, MPI_COMM_WORLD, &estado);

        sumaMatrices(M1, M2, resultado, renEnviar, m);

        MPI_Send(resultado, renEnviar * m, MPI_INT, 0, 0, MPI_COMM_WORLD);

        free(M1);
        free(M2);
        free(resultado);
    }

    MPI_Finalize();
    return 0;
}