#include <stdio.h>
#include <stdlib.h>
#include <mpi.h>

int main (int argc, char **argv){
    int id, np, dato[4], *datos;
    
    MPI_Init(&argc, &argv);
    MPI_Comm_rank(MPI_COMM_WORLD, &id);
    MPI_Comm_size(MPI_COMM_WORLD, &np);

    for(int i = 0; i < 4; i++){
        dato[i] = id + 1;
    }

    printf("El proceso %d tiene los siguientes datos: ", id);
    for(int i = 0; i < 4; i++){
        printf("%d ", dato[i]);
    }

    printf("\n");

    if(id == 0){
        datos = (int *)calloc(4*np, sizeof(int));
    }

    MPI_Gather(dato, 4, MPI_INT, datos, 4, MPI_INT, 0, MPI_COMM_WORLD);


    if(id == 0){
        printf("Los datos reunidos por el proceso raíz de los demás procesos son:\n");
        for(int i = 0; i < 4*np; i++){
            printf("%d", datos[i]);
        }
	printf("\n");
	free(datos);
    }

    MPI_Finalize();
return 0;

}
