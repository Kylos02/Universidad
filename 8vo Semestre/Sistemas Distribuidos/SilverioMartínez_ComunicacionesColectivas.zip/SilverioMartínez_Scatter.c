#include <stdio.h>
#include <stdlib.h>
#include <mpi.h>

int main(int argc, char **argv) {
    int id, np;
    int dato[4];  // Cada proceso recibirá 4 datos
    int *datos = NULL;  // Arreglo en el proceso raíz para enviar datos

    MPI_Init(&argc, &argv);
    MPI_Comm_rank(MPI_COMM_WORLD, &id);
    MPI_Comm_size(MPI_COMM_WORLD, &np);

    // El proceso raíz llena el arreglo de datos
    if (id == 0) {
        datos = (int *)calloc(4 * np, sizeof(int));  // Tamaño: 4 * np
        if (datos == NULL) {
            fprintf(stderr, "Error: No se pudo asignar memoria.\n");
            MPI_Abort(MPI_COMM_WORLD, 1);
        }
        for (int i = 0; i < 4 * np; i++) {
            datos[i] = i + 1;  // Llenar con valores de ejemplo
        }

        // Imprimir los datos que tiene el proceso raíz antes de distribuirlos
        printf("Proceso raíz (0) tiene los siguientes datos:\n");
        for (int i = 0; i < 4 * np; i++) {
            printf("%d ", datos[i]);
        }
        printf("\n");
    }

    // Distribuir los datos a todos los procesos
    MPI_Scatter(datos, 4, MPI_INT, dato, 4, MPI_INT, 0, MPI_COMM_WORLD);

    // Cada proceso imprime los datos que recibió
    printf("Proceso %d recibió: ", id);
    for (int i = 0; i < 4; i++) {
        printf("%d ", dato[i]);  // Imprimir los 4 datos recibidos
    }
    printf("\n");

    // Liberar memoria solo en el proceso raíz
    if (id == 0) {
        free(datos);
    }

    MPI_Finalize();
    return 0;
}