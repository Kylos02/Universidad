#include <stdio.h>
#include <mpi.h>

int main (int argc, char **argv){
    int id, np, dato[4], dator[4];
    
    MPI_Init(&argc, &argv);
    MPI_Comm_rank(MPI_COMM_WORLD, &id);
    MPI_Comm_size(MPI_COMM_WORLD, &np);

    for(int i = 0; i < 4; i++){
        dato[i] = id + 1;
    }

    printf("Proceso %d tiene los siguientes datos: ", id);
    for (int i = 0; i < 4; i++) {
        printf("%d ", dato[i]);
    }
    printf("\n");

    MPI_Reduce(dato, dator, 4, MPI_INT, MPI_SUM, 0, MPI_COMM_WORLD);

    if(id == 0){
        printf("Resultado de la suma en el proceso raiz:");
        for (int i = 0; i < 4; i++) {
            printf("%d ", dator[i]);
        }
    }

    printf("\n\n");
    MPI_Finalize();

return 0;

}